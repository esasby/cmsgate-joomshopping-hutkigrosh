<?php
require_once(dirname(__FILE__) . '/vendor/apiv3/cmsgate-core/src/apiv3/cmsgate/CmsPlugin.php');

use apiv3\cmsgate\hutkigrosh\RegistryHutkigroshJoomshopping;
use apiv3\cmsgate\CmsPlugin;


(new CmsPlugin(dirname(__FILE__) . '/vendor', dirname(__FILE__)))
    ->setRegistry(new RegistryHutkigroshJoomshopping())
    ->init();

