<?php
/*
* @info     Платёжный модуль Hutkigrosh для JoomShopping
* @package  hutkigrosh
* @author   esas.by
* @license  GNU/GPL
*/
defined('_JEXEC') or die();

use apiv3\cmsgate\hutkigrosh\controllers\ControllerHutkigroshAlfaclick;
use apiv3\cmsgate\hutkigrosh\controllers\ControllerHutkigroshNotify;
use apiv3\cmsgate\joomshopping\CmsgateControllerJoomshopping;
use apiv3\cmsgate\hutkigrosh\wrappers\ConfigWrapperHutkigrosh;
use apiv3\cmsgate\hutkigrosh\protocol\HutkigroshProtocol;
use apiv3\cmsgate\hutkigrosh\protocol\HutkigroshLoginRq;
use apiv3\cmsgate\hutkigrosh\utils\RequestParamsHutkigrosh;
use apiv3\cmsgate\utils\Logger as HgLogger;

require_once(JPATH_SITE . '/plugins/jshopping/hutkigrosh/init.php');

class JshoppingControllerHutkigrosh extends CmsgateControllerJoomshopping
{
    /**
     * Выставляет счет в альфаклик
     */
    function alfaclick()
    {
        try {
            $controller = new ControllerHutkigroshAlfaclick();
            $controller->process();
        } catch (Throwable $e) {
            HgLogger::getLogger("alfaclick")->error("Exception: ", $e);
        }
    }


    /**
     * Callback, который вызывает сам ХуткиГрош для оповещение об оплате счета в ЕРИП
     * Тут выполняется дополнительная проверка статуса счета на шлюза и при необходимости изменение его статус заказа
     * в локальной БД
     */
    function notify()
    {
        try {
            $controller = new ControllerHutkigroshNotify();
            $controller->process();
        } catch (Throwable $e) {
            HgLogger::getLogger("callback")->error("Exception:", $e);
        }
    }

    function service_provider()
    {
        try {
            ConfigWrapperHutkigrosh::fromRegistry()->setHutkigroshApiToken($_GET[RequestParamsHutkigrosh::API_TOKEN]);
            $hg = new HutkigroshProtocol(ConfigWrapperHutkigrosh::fromRegistry());
            $billLogin = new HutkigroshLoginRq();
            $hg->checkProviderMetadata($billLogin);
            echo json_encode( $hg->rqProviderMetadata );
            die;
        } catch (Throwable $e) {
            Logger::getLogger("callback")->error("Exception:", $e);
        }
    }
}