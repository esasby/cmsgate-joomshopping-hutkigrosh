<?php
/*
* @info     Платёжный модуль bgpb для JoomShopping
* @package  bgpb
* @author   esas.by
* @license  GNU/GPL
*/
require_once(JPATH_SITE . '/plugins/jshopping/hutkigrosh/init.php');

use apiv3\cmsgate\joomshopping\CmsgateModelJoomshopping;

defined('_JEXEC') or die();

class JshoppingModelHutkigrosh extends CmsgateModelJoomshopping
{

}