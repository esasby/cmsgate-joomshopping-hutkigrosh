<?php
/*
* @info     Платёжный модуль Hutkigrosh для JoomShopping
* @package  hutkigrosh
* @author   esas.by
* @license  GNU/GPL
*/

require_once(JPATH_SITE . '/plugins/jshopping/hutkigrosh/init.php');

use apiv3\cmsgate\joomshopping\CmsgatePlugin;
use apiv3\cmsgate\hutkigrosh\protocol\HutkigroshLoginRq;
use apiv3\cmsgate\hutkigrosh\protocol\HutkigroshProtocol;
use apiv3\cmsgate\hutkigrosh\wrappers\ConfigWrapperHutkigrosh;

defined('_JEXEC') or die;

class plgJShoppingHutkigrosh extends CmsgatePlugin
{
    public function onBeforeCompileHead()
    {
        $app = \Joomla\CMS\Factory::getApplication();

        // Проверяем, что мы в админке и открыты настройки именно этого плагина
        if ($app->isClient('administrator')
            && $app->input->get('option') == 'com_jshopping'
            && $app->input->get('controller') == 'payments'
            && $app->input->get('task') == 'edit'
        ) {
            $doc = \Joomla\CMS\Factory::getDocument();
            $doc->addScriptDeclaration( '
                    jQuery(document).ready(function($) {
                        const $tokenInput = $("#configform_common-api_token");
                        const $selectServices = $("#configform_common-service_id");
                        const $selectOutlets = $("#configform_common-retail_outlet_id");
                        const $selectCashboxes = $("#configform_common-cash_box_id");
                        let globalData = null;
                        const $refreshBtn = $(`<button type="button" class="button" style="margin-left: 10px;">Актуализировать</button>`);
                        $tokenInput.after($refreshBtn);
                        $refreshBtn.on("click", async function() {
                            const token = $tokenInput.val().trim();
                            if (!token) {
                                alert("Сначала введите API Token");
                                return;
                            }
                            const $allSelects = $selectServices.add($selectOutlets).add($selectCashboxes);
                            $refreshBtn.prop("disabled", true).text("Загрузка...");
                            $allSelects.prop("disabled", true).html("<option></option>");
                            $.ajax({
                                url: "index.php?option=com_jshopping&controller=payments&task=edit&hutkigrosh_ajax=1", // Глобальная переменная WP в админке
                                type: "GET",
                                dataType: "json",
                                data: {
                                    api_token: token
                                },
                                success: function(data) {
                                    if (data && typeof( data.message ) == "undefined") {
                                        globalData = data;
                                        renderOptions($selectServices, data.services);
                                        renderOptions($selectOutlets, data.retailOutlets);
                                        if (data.retailOutlets && data.retailOutlets.length > 0) {
                                            renderOptions($selectCashboxes, data.retailOutlets[0].cashBoxes);
                                        }
                                        $allSelects.prop("disabled", false);
                                    } else {
                                        if (data &&  data.message == "An internal server error occurred.") {
                                            alert("Вам исключительно повезло! На сервере ведутся технические работы, попробуйте через 15 минут.");
                                        }else{
                                            alert("Ошибка API или неверный токен. " + data.message);
                                        }
                                        $allSelects.prop("disabled", true).html("<option></option>");
                                    }
                                },
                                error: function() {
                                    alert("Ошибка соединения с сервером");
                                    $allSelects.prop("disabled", true).html("<option></option>");
                                },
                                complete: function() {
                                    $refreshBtn.prop("disabled", false).text("Актуализировать");
                                }
                            });
                        });
                        $selectOutlets.on("change", function() {
                            if (!globalData) return;
                            const selectedCode = $(this).val();
                            const outlet = globalData.retailOutlets.find(o => o.code == selectedCode);
                            if (outlet && outlet.cashBoxes) {
                                renderOptions($selectCashboxes, outlet.cashBoxes);
                            }
                        });
                        function renderOptions($el, items) {
                            let html = "";
                            if (items && items.length > 0) {
                                items.forEach(item => {
                                    html += `<option value="${item.code}">${item.name}</option>`;
                                });
                            } else {
                                html = `<option value="">Нет данных</option>`;
                            }
                            $el.html(html);
                        }
                    });
        ' );
        }
    }

    public function onBeforeEditPayments(&$view)
    {
        $app = \Joomla\CMS\Factory::getApplication();
        if ($app->input->get('hutkigrosh_ajax')) {
            try {
                ConfigWrapperHutkigrosh::fromRegistry()->setHutkigroshApiToken($app->input->get('api_token', '', 'string'));
                $hg = new HutkigroshProtocol(ConfigWrapperHutkigrosh::fromRegistry());
                $billLogin = new HutkigroshLoginRq();
                $hg->checkProviderMetadata($billLogin);
                echo json_encode( $hg->rqProviderMetadata );
                die;
            } catch (Throwable $e) {
                Logger::getLogger("callback")->error("Exception:", $e);
            }

            // 3. Отдаем JSON и прерываем выполнение Joomla (чтобы не вывелся HTML админки)
            header('Content-Type: application/json');
            echo json_encode($data);

            $app->close(); // Это критически важно!
        }
    }
}