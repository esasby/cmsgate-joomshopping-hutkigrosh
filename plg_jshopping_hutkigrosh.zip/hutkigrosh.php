<?php
/*
* @info     Платёжный модуль Hutkigrosh для JoomShopping
* @package  hutkigrosh
* @author   esas.by
* @license  GNU/GPL
*/

require_once(JPATH_SITE . '/plugins/jshopping/hutkigrosh/init.php');

use esas\cmsgate\joomshopping\CmsgatePlugin;

defined('_JEXEC') or die;

class plgJShoppingHutkigrosh extends CmsgatePlugin
{
}